function z = otimizada(x)


z= ; %fun�ao a ser otimizada